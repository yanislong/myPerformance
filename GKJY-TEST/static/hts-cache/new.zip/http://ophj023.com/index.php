<!DOCTYPE HTML>
<html>
<head>
		<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta charset="utf-8" />
	<title>首页-欧品鸿基-全屋定制-官网</title>
	<meta name="keywords" content="欧品鸿基,全屋定制家具厂家,高端原木定制家具,工程套装门厂家,佰益装饰,全屋定制招商" />
	<meta name="description" content="欧品鸿基是隶属佰益装饰工程有限公司旗下品牌之一，公司成立于2015年，品牌运营到多个城市专卖，得到市场一致的认可。公司拥有一批20年专业生产实木定制的老木匠。欧品鸿基生产车间采用最先进的数控雕刻机械。和木材养料榫卯结构处理技术，严苛的验收标准在行业内首屈一指。欧品鸿基全屋定制产品包含,定制衣柜、酒柜、鞋柜、榻榻米、书柜、阳台柜、室内套装门,厨卫门、橱柜门、原木柜门系列、护墙板系列。欧品鸿基设计,生产销售为一体,行业知名品牌!品质优！欧品鸿基通过研发、生产等沉淀积累，在木工、漆面处理等方面形成了完整的技术体" />
	<meta http-equiv="Cache-Control" content="no-transform" />
				<link rel="stylesheet" type="text/css" href="//v2.qiyuntong.com/ps/model19/red/1.css" />
			<style type='text/css'>
		.g-main,.g-hd-inner,.g-ft-inner{ width:1102px;}
	.g-ft,.g-hd-outer{min-width:1102px;}
	    			.g-ft{width:100%;position:static;min-height:80px;background: url(//cdn037.yun-img.com/static/upload/ophj023/focus/20190929173043_55721.jpg) ;}
		@font-face {
	  font-family: 'iconfont';  /* project id 1784547 */
	  src: url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.eot');
	  src: url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.eot?#iefix') format('embedded-opentype'),
	  url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.woff2') format('woff2'),
	  url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.woff') format('woff'),
	  url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.ttf') format('truetype'),
	  url('//at.alicdn.com/t/font_1784547_9e4hdrv88tp.svg#iconfont') format('svg');
	}
	.iconfont{
	  font-family:"iconfont" !important;
	  font-size:16px;font-style:normal;
	  -webkit-font-smoothing: antialiased;
	  -webkit-text-stroke-width: 0.2px;
	  -moz-osx-font-smoothing: grayscale;
	}

	</style>
		<script type="text/javascript" src="//v3.qiyuntong.com/pj/all/1.js"></script>
		<script type="text/javascript">
		var WEBQEUESTURL = window.location.href.toLowerCase();
		if((WEBQEUESTURL.indexOf('%3c')>0 && WEBQEUESTURL.indexOf('%3e')>0) || (WEBQEUESTURL.indexOf('<')>0 && WEBQEUESTURL.indexOf('>')>0)){
			window.location.href = '/404.html';
		}
		var WEB_ROOT = 'http://ophj023.com';
		$(function() {
			$("img.lazyload").lazyload({failure_limit:100, effect:"fadeIn", skip_invisible:false, threshold:200});
		});
		/* 初始化宽度 */
		var MainDocumentWidth = '1102';
		if(MainDocumentWidth!=""){
			if(MainDocumentWidth>$(window).width()){
				$('.g-document').width(MainDocumentWidth);
			}
		}
		
			</script>
	<!--[if lt IE 9]>
	<script src="/static/js/library/html5shiv/3.7.2/html5shiv.min.js?v=201504071709"></script>
	<![endif]-->
	
	<!-- 加载IE6对PNG图片透明的支持 -->
	<!--[if IE 6]>
	<script src="/static/js/library/dd_belatedpng/0.0.8/dd_belatedpng.min.js"></script>
	<![endif]-->
	
	<!-- 首部功能插件 end -->
</head>
<body>
<!-- 头部插件注入区 -->
<script type="text/javascript" src="/static/js/library/layer/layer.min.js"></script>
  <script type="text/javascript" src="/static/js/library/common/common.js"></script>

<!-- 头部 -->
<div class='g-document'>
<header class="g-hd">
<div class='g-hd-outer'>
<div class="g-hd-inner g-hd-limit">
	<!-- 头部980 -->
		<div class='g-hd-edit'>
		<!-- 头部自定义模块 -->
				<!-- 头部自定义模块 end -->
		<!-- LOGO -->
				<div class="m-logo"   style="position:relative;top:-2px;left:-2px;" id="set_logo">
			<a href="/"><img src="//cdn037.yun-img.com/static/upload/ophj023/logo/20191007153415_69162.png" alt=""  style="width:322px;height:81px;"></a>
		</div>
				<!-- LOGO end -->
		<div class="m-hd-top">
		<!--是否显示整体注册条-->
		<div class="m-head-regist">
															<a class="u-hd-btn u-trans" href="#"  id='set_translation' style="color:;">简繁切换<!-- 简繁切换 --></a>
																		<div class="clearing"></div>
			</div>
						<div id="for_search">
												<style type="text/css">
/*搜索框*/
.m-search { margin-top: 20px; float: right; border:none;}
.m-search .u-search-key {background: #fff; color: #999; float: none; font-size: 14px; height: 30px;width:300px;  padding:0;}
.m-search .u-search-btn { color: #fff; font-size: 14px; border: 0 none; height: 34px; overflow: hidden; width: 50px; float: right; cursor: pointer; text-indent: -99999px;margin-left: -2px;}


/*默认 颜色*/
.m-search .u-search-key { border: 2px solid #e8e8e8;  }
.m-search .u-search-btn {  background: url(/static/img/searchimg/search1/soso_default.jpg) no-repeat center; }
/*灰色*/
.m-search .u-search-key { border: 2px solid #666666;  }
.m-search .u-search-btn {  background: url(/static/img/searchimg/search1/soso_gray.jpg) no-repeat center; }
</style>
    <!--搜索框 开始 -->
    <div id="set_search" class="m-search">
        <input type="text" class="u-search-key" placeholder="请输入搜索内容">
        <input type="button" class="u-search-btn" value="搜索"  >
    </div>
    <!--搜索框 结束 -->
									</div>
		</div>
		<div class="clearing"></div>
		</div>
		<div class="clearing"></div>
		


<!-- 导航开始 strat -->
<!-- 浮动fixed -->
<div class="">
<div class='m-newnav' id='set_menu'>
<link href="/static/css/nav/common.css" rel="stylesheet" type="text/css" />
<style class='m-newnav-style'>
 

/*红色*/
.m-newnav { background: #fff; border-bottom: 2px solid #f03; }
.navList li li{background: #f21a29;}
.m-newnav ul li>a { color: #000; }
.m-newnav ul li:hover>a {background: none; color: #fff; }
.m-newnav ul ul>a:hover { color: #fff; }
.m-newnav .select>a { color: #000; }
.navCont .navigator_15_side:hover{background: #C20A17; transition: .5s all linear 0s; -webkit-transition: .5s all linear 0s;}
#buoy { background: #C20A17; }
.m-newnav .select { background: none;}
.m-newnav ul li ul,.m-newnav .navList ul li ul  { background: #f03;}
.m-newnav ul li ul li{ background: #C20A17;}
.navList li li a{ color: #fff;}
.m-newnav ul li .m-nav-coustom{background: #f21a29;}


/*浮动*/
.menu_fixed { position: fixed; top: 0px;  left:0;right:0; z-index: 9999;}
.menu_fixed .m-newnav{  height: 46px; line-height: 46px;  margin-top:0px;}


.navCont {position: relative; width: 1080px; margin: 0 auto; text-align:  left; }
#coreNav { display: inline-block; text-align: center; }


/*导航样式*/
.m-newnav{ border-radius:0px; }
.navList{ position:relative; padding-left:3px;}
.navList li{ position:relative; z-index:999; float:left; _display:inline; height:46px; font-size:18px; }
.m-newnav ul li a {   height: 46px; line-height: 46px; }
.m-newnav ul li ul li ul { background: none;}
.navList a{ display:inline-block;   height: 46px; line-height: 46px;  color:#fff;overflow: hidden;}
.navList .last,.productNav .navCont .navList .last{ background:none !important;}
.navList .active,.navList a:hover{ position:relative; z-index:100; }
.navList .hoverActive{ position:relative; z-index:100;}
.navList .hoverActive a{ background:none;}
.navList li ul{position:relative;}
.m-newnav ul ul li {width: 160px;}
.m-newnav ul ul li a {  width: 100%; }
 #buoy { position: absolute; width: 110px; height: 46px; bottom: 0px; left: -9999px; }
.m-newnav ul li ul { top: 46px; }
/*全部产品列表*/
.navCont .navigator_15_side{position: relative;display: inline-block;width: 120px;  height: 46px; line-height: 46px;  text-align: center; color: #fff; float: left; font-size: 18px;font-family: "Microsoft yahei","微软雅黑",Arial,Helvetica,sans-serif,"宋体"; cursor:pointer;}
.navCont .navigator_15_side a{ color:#000; text-decoration: none;}
.navCont .navigator_15_side a:hover{ color:#000; text-decoration: none; }

/*全部产品*/
.wrap {position: absolute; display:none;}
.all-sort-list { position:relative; width:120px; padding:0px 0px 3px 0px; background:#FAFAFA;border: 1px solid #ccc; border-top: none; }
.all-sort-list .item { height:40px; border-top:1px solid #FFFFFF; }
.all-sort-list .item.bo { border-top:none; } 
.all-sort-list .item h3 { height:40px; line-height:40px; border:1px 0px; font-size:14px; font-weight:normal; width:121px; overflow:hidden; }
.all-sort-list .hover h3 { position:relative; z-index:13; background:#FFF; border-color:#DDD; border-width:1px 0px; border-style:solid; }
.all-sort-list .item span { padding:0px 5px; color:#A40000; font-family:"\5B8B\4F53"; } 
.all-sort-list .item a { color:#000; text-decoration:none; }
.all-sort-list .item a:hover {color:#E4393C; }

.all-sort-list .item-list {  display:none; position:absolute;/* width:705px; */min-height:200px; _height:200px; background:#FFF; left:120px; box-shadow:0px 0px 10px #DDDDDD; border:1px solid #DDD; top:3px; z-index:10; }
.all-sort-list .item-list .close {  position:absolute; width:26px; height:26px; color:#FFFFFF; cursor:pointer; top:-1px; right:-26px; font-size:20px; line-height:20px; text-align:center; font-family:"Microsoft Yahei"; background:rgba(0, 0, 0, 0.6);  background-color:transparent\9; filter:progid:DXImageTransform.Microsoft.Gradient(GradientType=1, startColorstr='#60000000', endColorstr='#60000000'); }

.item-list .subitem { float:left; width:477px; padding:0px 4px 0px 8px; }
.item-list .subitem ul { border-top:1px solid #EEE; padding:6px 0px; overflow:hidden; zoom:1; }
.item-list .subitem .fore { border-top:none; }
.item-list .subitem ul {  overflow:hidden; }
.item-list .subitem ul li{  font-weight:normal; font-size:14px; }
.item-list .subitem ul li a { color:#666; text-decoration:none; }
.item-list .subitem ul li a:hover{ font-weight:normal; text-decoration:underline; }
.m-newnav ul li .m-nav-coustom{position: absolute;top:46px;display:none;text-align:left;color:white;}
.m-newnav .m-nav-coustom ul,.m-newnav .m-nav-coustom ul li, .m-newnav .m-nav-coustom ul li a, .m-newnav .m-nav-coustom a{float:none;width:auto;height:auto;z-index:0;margin:0;padding:0;line-height:inherit;visibility:none;}
.m-newnav .m-nav-coustom ul,.m-newnav .m-nav-coustom ul li{position:static;top:0;left:0;text-align:left;display:inline;}

</style>
    <div class="navCont">
    <!-- 全部产品start   -->
        <div id="" class="navigator_15_side">
            <a href="/product.html">全部产品</a>
            <div class="wrap">
        <div class="all-sort-list">
                         <div class="item">
                <h3><a href="product_798985.html">原木柜门系列</a></h3>
                            </div>
                        <div class="item">
                <h3><a href="product_798984.html">吸塑门系列</a></h3>
                            </div>
                        <div class="item">
                <h3><a href="product_783117.html">全屋定制柜</a></h3>
                            </div>
                        <div class="item">
                <h3><a href="product_783116.html">实木门系列</a></h3>
                            </div>
                        <div class="item">
                <h3><a href="product_783115.html">背景墙系列</a></h3>
                            </div>
                    </div>
    </div>

<script type="text/javascript">
     //全部产品列表
     // 二级
     $(".navCont .navigator_15_side").hover(function() {
            $(this).find(".wrap").show();
        },function() {
            $(this).find(".wrap").hide();
    });
    // 三级
    $('.all-sort-list > .item').hover(function(){
            var eq = $('.all-sort-list > .item').index(this),               //获取当前滑过是第几个元素
                h = $('.all-sort-list').offset().top,                       //获取当前下拉菜单距离窗口多少像素
                s = $(window).scrollTop(),                                  //获取游览器滚动了多少高度
                i = $(this).offset().top,                                   //当前元素滑过距离窗口多少像素
                item = $(this).children('.item-list').height(),             //下拉菜单子类内容容器的高度
                sort = $('.all-sort-list').height();                        //父类分类列表容器的高度
            
            if ( item < sort ){                                             //如果子类的高度小于父类的高度
                if ( eq == 0 ){
                    $(this).children('.item-list').css('top', (i-h));
                } else {
                    $(this).children('.item-list').css('top', (i-h)+1);
                }
            } else {
                if ( s > h ) {                                              //判断子类的显示位置，如果滚动的高度大于所有分类列表容器的高度
                    if ( i-s > 0 ){                                         //则 继续判断当前滑过容器的位置 是否有一半超出窗口一半在窗口内显示的Bug,
                        $(this).children('.item-list').css('top', (s-h)+2 );
                    } else {
                        $(this).children('.item-list').css('top', (s-h)-(-(i-s))+2 );
                    }
                } else {
                    $(this).children('.item-list').css('top', 0 );
                }
            }   

            $(this).addClass('hover');
            $(this).children('.item-list').css('display','block');
        },function(){
            $(this).removeClass('hover');
            $(this).children('.item-list').css('display','none');
        });

        $('.item > .item-list > .close').click(function(){
            $(this).parent().parent().removeClass('hover');
            $(this).parent().hide();
        });
</script>
</div>
<!-- 全部产品end     -->        
        <div class="navCont_s"> 
        <!-- 主菜单 -->
        <ul id="coreNav" class="navList">
             			<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/index.php" >网站首页</a>
				                        			            </li>
					<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/about.html" >公司简介</a>
				                        			            </li>
					<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/product.html" >产品中心</a>
				                        			            </li>
					<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/news.html" >新闻中心</a>
				                        			            </li>
					<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/contact.html" >联系我们</a>
				                        			            </li>
					<li class="active">  
			<div id="buoy"></div>
            								<a  class="first-a" href="/message.html" >在线留言</a>
				                        			            </li>
		 
        </ul>                 
        </div>


<div style="clear:both"></div>
<script type="text/javascript">
var SYSPAGEURL = window.location.pathname + window.location.search;
if(SYSPAGEURL=='/index.html' || SYSPAGEURL=='/index.php' || SYSPAGEURL==''){
    SYSPAGEURL = '/';
}
$(document).ready(function(){
        $('.m-newnav').levelmenu();
    
    $(".m-newnav .select").removeClass('select');
    $(".m-newnav a[href='" + SYSPAGEURL + "']").parent().addClass('select');
});

$.fn.levelmenu = function(){
    $(this).css('overflow','visible');
    $(this).css('z-index','999');
    var overmax = false;
    var parent = this;
    $('>ul>li', this).each(function(){
        if(overmax){
            $('<li>'+$(this).html()+'</li>').appendTo($('.more', parent));
            $(this).remove();
        }else{
            if($(this).next().length>0){
                if($(this).offset().left > $(this).next().offset().left){
                    $('<li><a href="#">更多</a><ul class="more"></ul></li>').appendTo($(">ul", parent));
                    $('.more', parent).addClass('last');
                    $('<li>'+$(this).html()+'</li>').appendTo($('.more', parent));
                    $(this).remove();
                    overmax = true;
                }
            }else{
                if($(this).find('ul ul:first').length>0){
                    $(this).find('ul:first').addClass('last');
                }
            }
        }
    });

    $("ul ul", this).css({display: "none"});
    $("ul li", this).hover(
        function(){
            $(this).addClass('select').find('.m-nav-coustom,ul:first').css({visibility: "visible",display: "none"}).slideToggle(400);
        },function(){
            $(this).removeClass('select').find('.m-nav-coustom,ul:first').css({visibility: "hidden"});
            $(".m-newnav a[href='" + SYSPAGEURL + "']").parent().addClass('select');
        }
    );
};
//导航浮动
$(function(){
var top_menu = $('.m-newnav');
var _width = $(window).width();
top_menu.parent().removeClass('menu_fixed');
$(window).scroll(function(){
    var scroH = $(this).scrollTop();

    if(scroH > $(".g-hd-outer").height()){
        top_menu.parent().addClass('menu_fixed');
    }           
    else{
        top_menu.parent().removeClass('menu_fixed');
    }
})  
})

//导航hover滑动
; 
(function ($) {
    $.extend({
        'nicenav': function (con) {
            con = typeof con === 'number' ? con : 400;
            var $lis = $('#coreNav>li'), $h = $('#buoy')
            $lis.hover(function () {
                $h.stop().animate({
                    'left': $(this).offsetParent().context.offsetLeft
                }, con);
            }, function () {
                $h.stop().animate({
                    'left': '-9999px'
                }, con);
            })
        }
    });
}(jQuery));
 $.nicenav(300);
</script>   <!-- 头部980 end -->
</div>
</div>
</div>
<!-- 导航结束 end -->	<!-- 头部980 end -->
</div>
</div>

<!-- 头部 end1 -->
<div class="m-focus" id="set_focus" >
	<style type='text/css'>
	.m-focus, .m-focus .bd li, .m-focus .bd li a{height:600px}
	.m-focus{width:100%;position:relative;}
	.m-focus .bd{margin:0 auto;position:relative;z-index:0;overflow:hidden;}
	.m-focus .bd ul{width:100% !important;}
	.m-focus .bd li{width:100% !important;overflow:hidden;text-align:center;background-repeat:no-repeat; background-position:center 0;}
	.m-focus .bd li a{display:block;}
	.m-focus .hd{width:100%;position:absolute; z-index:1; bottom:0; left:0; height:30px; line-height:30px;}
	.m-focus .hd ul{text-align:center;}
	.m-focus .hd ul li{cursor:pointer; display:inline-block; *display:inline; zoom:1; width:42px; height:11px; margin:1px; overflow:hidden; background:#000;filter:alpha(opacity=50);opacity:0.5;  line-height:999px; }
	.m-focus .hd ul .on{background:#f00;}
	.m-focus .prev,.m-focus .next{display:block;  position:absolute; z-index:1; top:50%; margin-top:-30px; left:15%;  z-index:1; width:40px; height:60px; background:url(/static/theme/common/img/focus/focus1/slider-arrow.png) -126px -137px #000 no-repeat;  cursor:pointer; filter:alpha(opacity=50);opacity:0.5; display:none;  }
	.m-focus .next{left:auto; right:15%; background-position:-6px -137px;}
	</style>
	<div class="bd">
		<ul>
						<li _src="url(http://i.sendong.com/static/upload/default/focus/pcfocus1.jpg)" style=" ">
						<a target="_blank" href="#"  alt="焦点图一"></a>
						</li>
						<li _src="url(http://cdn033.yun-img.com/static/upload/a00201c1/focus/20160713133750_83447.jpg)" style=" ">
						<a target="_blank" href="#"  alt="焦点图一"></a>
						</li>
					</ul>
	</div>

	<div class="hd"><ul></ul></div>
	<span class="prev"></span>
	<span class="next"></span>
	<script type="text/javascript">
		function RunFocus(){
			var focus_auto = "1";
			var focus_time = "3000";
			jQuery(".m-focus").hover(function(){ jQuery(this).find(".prev,.next").stop(true,true).fadeTo("show",0.5) },function(){ jQuery(this).find(".prev,.next").fadeOut() });

			jQuery(".m-focus").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:focus_auto,interTime:focus_time, autoPage:true, trigger:"click",
				startFun:function(i){
					var curLi = jQuery(".m-focus .bd li").eq(i);
					if( !!curLi.attr("_src") ){
						curLi.css("background-image",curLi.attr("_src")).removeAttr("_src");
					}
				}
			});
		}
		RunFocus();
	</script>
</div><!-- 拖拽980 -->
</header><div class="g-main">
<script src="../static/js/scrollReveal.js"></script>
<script>
	$(function(){
		window.scrollReveal = new scrollReveal();
	})
</script>

<!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_1" style='width:1102px;height:184px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713134615_98164.png" alt="" /></div>
	</div>
</div>
<!-- 模块 end  duangou-->
<!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_2" style='width:269px;height:660px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><table style="width:100%;" cellpadding="2" cellspacing="0" border="0" class="ke-zeroborder" bordercolor="#000000">
	<tbody>
		<tr>
			<td>
				<a href="/teamview_525269.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713134911_17034.png" alt="" /></a><br />
			</td>
		</tr>
		<tr>
			<td>
				<a href="/teamview_525245.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713134919_88490.png" alt="" /></a><br />
			</td>
		</tr>
	</tbody>
</table>
<br /></div>
	</div>
</div>
<!-- 模块 end  duangou-->
<!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_3" style='width:278px;height:660px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><table style="width:100%;" cellpadding="2" cellspacing="0" border="0" class="ke-zeroborder" bordercolor="#000000">
	<tbody>
		<tr>
			<td>
				<a href="/teamview_525246.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713135726_22019.png" alt="" /></a><br />
			</td>
		</tr>
		<tr>
			<td>
				<a href="/teamview_525266.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713135734_68450.png" alt="" /></a><br />
			</td>
		</tr>
	</tbody>
</table>
<br /></div>
	</div>
</div>
<!-- 模块 end  duangou-->
<!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_4" style='width:268px;height:660px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><table style="width:100%;" cellpadding="2" cellspacing="0" border="0" class="ke-zeroborder" bordercolor="#000000">
	<tbody>
		<tr>
			<td>
				<a href="/teamview_525268.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713140308_82619.png" alt="" /></a><br />
			</td>
		</tr>
		<tr>
			<td>
				<a href="/product.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713140315_88753.png" alt="" /></a><br />
			</td>
		</tr>
	</tbody>
</table>
<br /></div>
	</div>
</div>
<!-- 模块 end  duangou-->
<!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_5" style='width:283px;height:660px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><table style="width:100%;" cellpadding="2" cellspacing="0" border="0" class="ke-zeroborder" bordercolor="#000000">
	<tbody>
		<tr>
			<td>
				<a href="/teamview_525246.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713140449_96803.png" alt="" /></a><br />
			</td>
<td style="width=" 105px;"=""> <br />
				</td>
					</tr>
					<tr>
						<td>
							<a href="/teamview_525266.html" target="_blank"><img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713140456_54480.png" alt="" /></a><br />
						</td>
						<td>
							<br />
						</td>
					</tr>
						</tbody>
							</table>
<br /></div>
	</div>
</div>
<!-- 模块 end  duangou-->


<!-- 公司简介模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_7" style='width:1102px;height:269px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class="m-theme11"> 
			<p style="line-height: 3em;"><span style="font-size: 16px;">欧品鸿基是隶属佰益装饰工程有限公司旗下品牌之一，公司成立于2015年，品牌运营到多个城市专卖，得到市场一致的认可。公司拥有一批20年专业生产实木定制的老木匠。欧品鸿基生产车间采用最先进的数控雕刻机械。和木材养料榫卯结构处理技术，严苛的验收标准在行业内首屈一指。欧品鸿基全屋定制产品包含,定制衣柜、酒柜、鞋柜、榻榻米、书柜、阳台柜、室内套装门,厨卫门、橱柜门、原木柜门系列、护墙板系列。欧品鸿基设计,生产销售为一体,品质优！欧品鸿基通过研发、生产等沉淀积累，在木工、漆面处理等方面形成了完整的技术体系，在为客户提高装修工程效率，降低生产成本，提高产品质量等方面发挥了重要作用，并得到市场的广泛认可。&nbsp;&nbsp;公司目前配套定制柜体车间、套装门车间、原木系列车间，成套数控生产线及先进的现代化生产设备，可提供上千种产品，来满足客户的多样化需求。公司现有一支经验丰富，素质优良的设计、生产、管理、营销团队，并与上下游供应商、服务商建立起稳固的合作关系。<br/>我们的优势：<br/>产品具有环保、耐用、防潮、耐腐蚀、不褪色、隔音好等特点，，先进的设备，超前的设计，精细的做工，综合流光溢彩的玻璃工艺，无论款式，性能还是质量均属上乘，经久耐用的独特优势的现代家居装潢中真正的绿色环保产品。公司以雄厚的资金，精湛的技术，健康的管理机制和完善的营销网络，成就了品牌的健康发展，塑造了品牌的良好形象，走进了千家万户，深受广大消费者的欢迎，美誉度响于国内外。</span></p><p style="line-height: 3em;"><span style="font-size: 16px;">公司理念：<br/>公司结合现代人们提倡的人文和谐理念，始终倡导了一种理想主义的价值观和社会责任，注重员工素质培养，以“专心做事、用感恩的心做人”公司精神，凝聚员工的热诚和公司强大的研发能力，为客户打开方便之门。历经多年风雨沉淀，将“匠心品质.鸿基伟业”的企业精神理念融入产品制造中去，通过不懈的努力，为广大朋友们搭建着共同发展的良好平台，是全国经销商，国内外贸易商，房地产开发商等的较佳合作伙伴。<br/>我们真诚期待你的加入，共创辉煌！&nbsp;</span></p>		</div>
	</div>
</div> 
<!-- 模块 end --><!-- 站点公告中心模块 -->
<div class="m-wg m-default m-default-default" id="visualmodule_9" style='width:1098px;height:93px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<div class='m-theme28'><div style="text-align:center;">
	<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/visualtoolkit/20160713142803_15197.png" alt="" /> 
</div></div>
	</div>
</div>
<!-- 模块 end  duangou-->
<div class="m-wg m-default m-default-default" id="visualmodule_10" style='width:1098px;height:806px;float:left;border-style:none;border-width:0px;border-color:#333333;margin-left:0px;margin-right:0px;margin-top:10px;margin-bottom:10px;padding-left:0px;padding-right:0px;padding-top:0px;padding-bottom:0px;'>
			<div class="m-wg-ct">
		<!-- 图片简介栏目 -->
		<div class="m-theme80">
			<ul>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910525.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714142245_57053.jpg" alt="当前中国家纺市场现状及前景预测">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910525.html" target="_blank">当前中国家纺市场现状及前景预测</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910525.html" target="_blank">
							随着近年来家居业“重装饰，轻装修”的潮流，家用纺织品越来越由实用性的作用提升到装饰性的作用，家纺行业被前所未有的“激活”了。	  2006年全社会家纺行业产值达到6540亿元，比上年增长了20%。2006年家纺产品出口......
						</a>
						</div>
					</div>
				</li>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910524.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714142139_90458.jpg" alt="家纺行业：从价值链的薄弱环节找到突破口">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910524.html" target="_blank">家纺行业：从价值链的薄弱环节找到突破口</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910524.html" target="_blank">
						随着家纺市场的发展，消费需求结构有了显著的改变。如果家纺企业仍不改进商业模式，必然造成产品结构单一和同质化、品牌建设泛泛化、渠道同质化、赢利模式同质化、竞争手段粗放简单、企业创新乏力的结局。在整个家纺行业的快速增长时期，......
						</a>
						</div>
					</div>
				</li>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910523.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714142050_34079.jpg" alt="家纺与电影">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910523.html" target="_blank">家纺与电影</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910523.html" target="_blank">
						经常逛家居店的朋友一定会发现，跟电影相关的家纺用品正悄然流行。7月15号，《哈利·波特与混血王子》刚一上市，多喜爱床品就顺势推出了跟哈利相关的一系列家纺产品，引起了轰动，算得上是一次大胆创新。　　类似的例子还有很多。20......
						</a>
						</div>
					</div>
				</li>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910522.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714141947_93890.jpg" alt="端午节家电大力促销">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910522.html" target="_blank">端午节家电大力促销</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910522.html" target="_blank">
							即将到来的端午节小长假，自然少不了各大家电卖场的大力促销，由于恰逢四年一届的世界杯和刚刚结束的高考，今年的节日促销也因此显得颇具新意。据悉，面向球迷的世界杯家电降价、买赠以及针对学生消费的数码3C产品促销近日已经悄然展......
						</a>
						</div>
					</div>
				</li>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910521.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714141718_38973.jpg" alt="有意实施行业内重组 蕴藏可升值资产">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910521.html" target="_blank">有意实施行业内重组 蕴藏可升值资产</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910521.html" target="_blank">
							近期身陷“财务造假”风波的四川XXX交出了一份亮丽的年报。4月7日，四川XXX公告称，去年实现净利润1.16亿元，同比增长272.17%。同时，公司董事会通过了以资本公积金向全体股东每10股转增5股的方案。XXX方面表......
						</a>
						</div>
					</div>
				</li>
									<li>
									
					<div class="m-theme80-img">
						<a href="/newsdetail_1910520.html" target="_blank">
							<img class='lazyload' data-original="http://cdn033.yun-img.com/static/upload/a00201c1/news/20160714141635_61476.jpg" alt="迎|“十一”主题优惠即将开幕">
						</a>
					</div>
					<div class="m-theme80-content">
						<div class="m-theme80-title">
							<a href="/newsdetail_1910520.html" target="_blank">迎|“十一”主题优惠即将开幕</a>
						</div>
						<div class="m-theme80-txt">
						<a href="/newsdetail_1910520.html" target="_blank">
							在六一第一波的节日促销打折活动后,新一波的“国庆”、“十一”促销打折马上就要开幕。	 由于端午是今年上半年最后一个假期,气候相对比较舒适，正式广大消费者外出购物的好时机，值此，我公司针对“端午、六一”,也推出了多种主题......
						</a>
						</div>
					</div>
				</li>
								</ul>
			<div class="clearing">&nbsp;</div>
		</div>
		<!-- 图片简介栏目 end -->
	</div>
</div><div class='g-main-clear' style='clear:both'></div>
</div>
<!-- 拖拽980 -->
<!-- 脚部 -->
<footer class="g-ft g-ft-edit">
	<!-- 脚部980 -->
	<div class="g-ft-inner">
		<!-- 脚部自定义模块 -->
				<!-- 脚部自定义模块 end -->
		<!-- 脚部菜单 -->
				<div class="m-ft-nav" id="set_footmenu" >
					</div>
				<!-- 脚部菜单 end -->
		<!-- 脚部信息 -->
		<div class="m-ft-text">
						<span id="set_copyright" >copyright © 2020 天府新区成都片区华阳欧品鸿基家具经营部 </span>
									<span id="set_beian" ><a target="_blank" href="http://www.beian.miit.gov.cn/"> 蜀ICP备19034599号-1</a>&nbsp;&nbsp;&nbsp;</span>
									<span id="police_cont" >&nbsp;&nbsp;&nbsp;</span>
									<span id="set_telphone" >18623066739&nbsp;&nbsp;&nbsp;</span>
									<span id="set_address" >成都市天府新区华阳街道南湖路&nbsp;&nbsp;&nbsp;</span>
									<span id="set_manage" ><a href="/yunadmin/login.php">后台管理</a></span>
					</div>
		<!-- 脚部信息 end -->
	</div>
	<!-- 脚部980 end -->
</footer>
<!-- 脚部 end -->
</div>
<!-- 拖拽JS -->
<!-- 脚部功能插件 -->
<!-- 底部插件注入区 -->
<center></center>

<bgsound src="" loop="-1">
<div id="set_trigger_login"></div></body>
</html>